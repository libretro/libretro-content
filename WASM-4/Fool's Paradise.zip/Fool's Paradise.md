---
author: Dave Purdum
github: rutrum
date: 2022-01-23 00:00:32 GMT
---

# Fool's Paradise

A submission to the WASM-4 game jam.

Original page on [itch.io](https://rutrum.itch.io/fools-paradise).
