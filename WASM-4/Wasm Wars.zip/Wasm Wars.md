---
author: Daniel Kiyoshi
github: Kiyoshi364
date: 2022-01-23 00:00:16 GMT
---

# Wasm Wars

A submission to the WASM-4 game jam.

Original page on [itch.io](https://shikiyo364.itch.io/wasm-wars).
