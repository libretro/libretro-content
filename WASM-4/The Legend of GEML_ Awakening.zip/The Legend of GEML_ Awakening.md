---
author: Robby Zampino, Ethan Hunter
github: restitux
date: 2022-01-23 00:00:20 GMT
---

# The Legend of GEML: Awakening

A submission to the WASM-4 game jam.

Original page on [itch.io](https://spaceman1701.itch.io/the-legend-of-geml-awakening).
