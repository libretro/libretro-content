---
author: Lázaro Albuquerque
github: lzralbu
date: 2022-01-23 00:00:13 GMT
---

# Smash Sugar Parallelepipeds

A submission to the WASM-4 game jam.

Original page on [itch.io](https://lzralbu.itch.io/smash-sugar-parallelepipeds).
