---
author: Bruno Garcia
github: aduros
date: 2021-09-02
---

# Raw Assembly Test