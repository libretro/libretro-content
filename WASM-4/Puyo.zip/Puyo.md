---
author: Shigeki Karita
github: ShigekiKarita
date: 2022-01-23 00:00:14 GMT
---

# Puyo

A submission to the WASM-4 game jam.

Original page on [itch.io](https://kari-tech.itch.io/puyo).
