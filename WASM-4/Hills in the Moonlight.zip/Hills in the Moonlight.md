---
author: Samarth Hattangady
github: samhattangady
date: 2022-01-23 00:00:34 GMT
---

# Hills in the Moonlight

A submission to the WASM-4 game jam.

Original page on [itch.io](https://chapliboy.itch.io/hills-in-the-moonlight).
