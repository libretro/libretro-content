---
author: MFauzan26
github: MFauzan26
date: 2022-01-23 00:00:25 GMT
---

# HAMMER JOE

A submission to the WASM-4 game jam.

Original page on [itch.io](https://mfproject.itch.io/hammer-joe).
