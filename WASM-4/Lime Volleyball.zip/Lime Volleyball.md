---
author: Bruno Garcia
github: aduros
date: 2022-01-23 00:00:33 GMT
---

# Lime Volleyball

A submission to the WASM-4 game jam.

Original page on [itch.io](https://aduros.itch.io/lime-volleyball).
