---
author: unnick
github: kcinnu
date: 2021-10-19
---

# Plasma Cube