---
author: Eduardo Bart
github: edubart
date: 2022-01-23 00:00:44 GMT
---

# Antcopter

A submission to the WASM-4 game jam.

Original page on [itch.io](https://edubart.itch.io/antcopter).
