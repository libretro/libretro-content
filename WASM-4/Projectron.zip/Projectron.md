---
author: James McMurray
github: jamesmcm
date: 2022-01-23 00:00:10 GMT
---

# Projectron

A submission to the WASM-4 game jam.

Original page on [itch.io](https://jamesmcm.itch.io/projectron).
