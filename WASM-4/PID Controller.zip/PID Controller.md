---
author: rezajamesahmed
github: ghost
date: 2022-01-23 00:00:15 GMT
---

# PID Controller

A submission to the WASM-4 game jam.

Original page on [itch.io](https://rezajamesahmed.itch.io/pid-controller-wasm4).
