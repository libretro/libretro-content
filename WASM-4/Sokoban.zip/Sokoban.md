---
author: Lars Hamre
github: chemecse
date: 2022-01-23 00:00:24 GMT
---

# Sokoban

A submission to the WASM-4 game jam.

Original page on [itch.io](https://chemecse.itch.io/w4-sokoban).
