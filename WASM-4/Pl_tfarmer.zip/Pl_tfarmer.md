---
author: pfg
github: pfgithub
date: 2022-01-23 00:00:36 GMT
---

# Pl¢tfarmer

A submission to the WASM-4 game jam.

Original page on [itch.io](https://pfg.itch.io/plctfarmer).
