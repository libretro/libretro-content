---
author: Dennis Ranke
github: exoticorn
date: 2021-11-11
---

# Skip Ahead