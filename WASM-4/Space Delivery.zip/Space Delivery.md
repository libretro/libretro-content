---
author: kirinokirino
github: kirinokirino
date: 2022-01-23 00:00:30 GMT
---

# Space Delivery

A submission to the WASM-4 game jam.

Original page on [itch.io](https://kirinokirino.itch.io/space-delivery).
