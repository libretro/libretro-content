---
author: Vitaly
github: madwareru
date: 2022-01-23 00:00:19 GMT
---

# Lumber Night

A submission to the WASM-4 game jam.

Original page on [itch.io](https://madware.itch.io/lumber-night).
