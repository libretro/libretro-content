---
author: William Guimont-Martin
github: willGuimont
date: 2022-01-23 00:00:31 GMT
---

# Rolly Dango

A submission to the WASM-4 game jam.

Original page on [itch.io](https://willguimont.itch.io/rolly-dango).
