---
author: Marcus Ramse
github: JerwuQu
date: 2022-01-23 00:00:42 GMT
---

# wasm4nia

A submission to the WASM-4 game jam.

Original page on [itch.io](https://jerwuqu.itch.io/wasm4nia).
