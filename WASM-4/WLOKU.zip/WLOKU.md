---
author: 12Boti
github: 12Boti
date: 2022-01-23 00:00:17 GMT
---

# WLOKU

A submission to the WASM-4 game jam.

Original page on [itch.io](https://12boti.itch.io/wloku).
