---
author: Dial0
github: ghost
date: 2022-01-23 00:00:26 GMT
---

# Tail Gunner

A submission to the WASM-4 game jam.

Original page on [itch.io](https://dial0.itch.io/tail-gunner).
