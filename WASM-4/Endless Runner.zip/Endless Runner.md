---
author: Richard McCormack
github: DenialAdams
date: 2021-11-07
---

# Endless Runner