This folder is where screenshots taken in the world editor are written there.

Press the [INSERT] key to take a screenshot.

Three files are written out for each screenshot: a full size image (2x pixels), preview size (1x pixels), and thumbnail size (0.5 pixels).

The files are named using the same name as the map file with the ".png" extension.

When taking screenshots of worlds, the screenshots will ALWAYS print out the entire world, regardless of where the camera is positioned in the world editor. Vehicles are displayed as well.