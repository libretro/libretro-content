This folder is where default special maps for the following events are handled:
- Pipe Minigame (Minigame Mode default)
- Boss Minigame (Minigame Mode/Tour Mode defaults)
- Boxes Minigame (Minigame Mode default)
- Bonus House/Shop (World Mode)

WARNING: Removing any of these files will result in possible glitches.