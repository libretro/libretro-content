--------------------------------------------
Level Editor GFX Folder - Help
--------------------------------------------
Please read this before continuing.

== leveleditor folder ==
This folder contains assets for the level editor and world editor. It is not recommended to change them a lot as it will cause parts of the editors to not display properly or even crash. Unless if you wanna go the extra mile for some more personalization, don't change anything inside this folder.

Here's a breakdown of where the graphics are used:

- leveleditor_background_levels - Used for background/foreground layer selection
- leveleditor_dialog - Used for various prompts such as exiting the editor
- leveleditor_eyecandy - Icons for the eyecandy seen in the Eyecandy menu (press E)
- leveleditor_hidden_marker - Used as a tickmark for options like setting special blocks to hidden (press K)
- leveleditor_maphazard_buttons - Icons and button for choosing a new hazard (press H)
- leveleditor_mapitems - Map Item select (press O), has preview and thumbnail versions
- leveleditor_mapnotfound - A placeholder icon that appears if the player attempts to load a non-existent map in World Editor
- leveleditor_noitemspawntile - Icon for the no item spawn zone (press Z)
- leveleditor_nospawntile - Icons for the no player spawn zones (press X). Gray is global, and red to blue is for preventing players 1, 2, 3, or 4 from respawning.
- leveleditor_pathtype_buttons - Icons for the type of platform path (Platforms: Press P)
- leveleditor_platform - Platform/hazard menu, ID buttons for each platform and hazard, and platform path dots (only seen when editing a platform's path). Platforms use up to ID 8, while hazards use up to ID 32.
- leveleditor_platform_path - Paths for all platforms, displayed as translucent colorful dots in map screenshots.
- leveleditor_platformstarttile - Starting point of a platform path (set with left-click)
- leveleditor_powerup_selector - Used in ? Block/View Block properties (press K), shows powerup frequency
- leveleditor_selectedtile - Used as tile selection highlights in Move Mode. Also used as a platform path end point.
- leveleditor_shade - Used for darkening the background
- leveleditor_tile_types - Tile types as displayed in the Tilesets Menu.
- leveleditor_transparent_tiles - Tile types displayed on the map in Tile Type mode (press L).
- leveleditor_warp - Warps for Warp mode (press W). Also has preview and thumbnail versions.
- leveleditor_world_path - Player paths for World Editor. These are needed to ensure the player can move around a world.
- menu_plain_field - Menu interface
- menu_selectfield - Menu interface, mainly for making selections
- vehicle_icons - Icons for the vehicles in World editor.