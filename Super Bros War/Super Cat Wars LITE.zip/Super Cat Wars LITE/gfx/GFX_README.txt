--------------------------------------------
GFX Folder - Help
--------------------------------------------
Please read this before continuing.

== leveleditor folder ==
This folder contains assets for the level editor and world editor. It is not recommended to change them a lot as it will cause parts of the editors to not display properly or even crash. Unless if you wanna go the extra mile for some more personalization, don't change anything inside this folder.

== packs folder ==
- If you want to add new graphics packs, check the packs folder and its README file.
- If you want to add new backgrounds, please go to packs/Classic/backgrounds.
- If you want to add new tilesets, please go to packs/Classic/tilesets.

== skins folder ==
Skins are 24-bit BMP files that are used to load playable character frames for the game. For accessibility, here's information about how skins work.

- Each skin uses a file format of 24-bit BMP, and they come in 2x pixel frames.
- The frames in order of appearance are Stand-Walk-Jump-Turn-Die-Stomped.
-- Standing, walking, and jumping frames require the player to face right. If it faces left, the animation will make it seem like the player is going backwards.
-- Turning frame may require the player to face left while doing a skidding animation.
-- Die frame displays when the player dies from a hazard or item instead of getting stomped.
- Each frame is 32x32 in its final product, 192x32 for the entire image.
- It's recommended to make 2x-pixel skins. 1x pixel skins can be placed in-game, but they don't look really nice. You can start working with 16x16 frames (on a 96x16 template), then resize them to 2x pixels and then saving them here.
- Palettes are listed in the Game Guide, but they are listed here for convenience (for those who want to work with MS Paint or Paint.NET):
(note: all palettes are in hex code format)

- BLACK (X) - #000000
- OUTLINE (Black in-game, flashes white when shielded or invincible) - #808080
- White (X) - #FFFFFF
- Transparent - #FF00FF
- Transparent Shield - #C0C0C0

TEAM 1 (Main color)
- Light - #FF0000
- Dark shade - #C00000
- Darker shade - #800000

TEAM 2 (Extra)
- Light - #C0C0FF
- Dark shade - #8080FF
- Darker shade - #4040FF

TEAM 3 (Blue/Red (displays as blue on P1 to P3, red on P4))
- Light - #0000FF
- Dark shade - #0000C0
- Darker shade - #000080

BROWN
- Light - #00FF00
- Dark shade - #00C000
- Darker shade - #008000

SKIN TONE
- Light - #FFFF00
- Dark shade - #C0C000
- Darker shade - #808000

GREY/WHITE
- White - #C000C0
- Gray - #800080
- Dark Gray - #400040

GOLD/WHITE
- White - #00FFFF
- Gold - #00C0C0
- Dark Gold - #008080
