--------------------------------------------
COLORBLIND GFX PACK
--------------------------------------------

This GFX pack is available by default and is meant for use in Super Cat Wars. This GFX pack lets players use graphics that adhere to support for colorblind users. Many mode objects and powerups have been given special indicators to differentiate further than merely by color.

Some maps may make use of tilesets that resemble their special block counterparts, but are not animated. To avoid confusion, you may also use the Colorblind GFX Pack. (Note this may break the point of troll maps!)