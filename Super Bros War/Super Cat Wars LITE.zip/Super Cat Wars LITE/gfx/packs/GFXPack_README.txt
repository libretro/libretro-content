--------------------------------------------
GFX Packs - HELP
--------------------------------------------
Welcome to Graphics Packs! These are special graphics you can change in Super Cat Wars/Super Mario War to suit the game to your liking. Take note of the following folders and how the game should handle changes to them.

You can copy the Classic GFX Pack and use it to make your very own graphics pack. Said folder will become available to select if you check your graphics settings in the game. Any GFX packs outside of Classic cannot have the tilesets and backgrounds folders, so they must be deleted. (Note: DO NOT DELETE ANY OF THE GRAPHICS IN THE CLASSIC FOLDER OTHERWISE THEY'LL BE UNABLE TO BE DISPLAYED PROPERLY OR CAUSE GAME CRASHES.)

The default standard for graphics in a GFX Pack uses a file format of 24-bit PNG files. modeskins uses 24-bit BMP, a default file format for skins.

MENU GRAPHICS
- menu - Contains assets for the main menu interface, as well as its own menu fonts.
-- In other folders, any graphics tagged "menu" should also change if Menu Graphics is set to your GFX pack of your choice.

GAME GRAPHICS
- awards - For death/kills eyecandy, as well as the cursor used on the Roulette Wheel
- blocks - All special blocks in the game
- eyecandy - All eyecandy/effects displayed in the game
- fonts - In-game fonts, used for tracking lives, player statuses, race goals, and more. THIS IS DIFFERENT FROM MENU FONTS AND ARE NOT USED BY THE MAIN MENU.
- hazards - In-game hazards, these are enemies that serve as a hindrance to players on the map even outside of Stomp Mode
- modeobjects - Contains graphics for the various gamemodes, like Yoshi's Eggs, Stomp, bosses, Star, Capture the Flag, and more
- modeskins - Used to handle the skins for Bobomb (Kobolt Jr/Bob-omb Powerup), Chicken (Chicken mode), and ShyGuy/Robot (Shy Guy Tag/Robo Tag)
- powerups - All powerups in the game.
- projectiles - All player projectiles in four colors.

WORLD GRAPHICS
- world - Graphics displayed on the world map, including ground tiles, decoration, interfaces, and more

CLASSIC GFX PACK ONLY
- backgrounds - Contains all the backgrounds the game will load in maps. These backgrounds are 640x480.
-- Backgrounds that are less than the required 640x480 dimensions will result in glitches such as afterimages and bugged level editor background scrolling.
-- See Backgrounds_README text file for more information.

- tilesets - Contains all the tilesets the game will load in maps
-- See the Tilesets_README text file for more information.