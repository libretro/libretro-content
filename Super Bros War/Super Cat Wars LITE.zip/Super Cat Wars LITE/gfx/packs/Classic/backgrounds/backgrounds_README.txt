--------------------------------------------
BACKGROUNDS
--------------------------------------------

It looks like you're entering the backgrounds folder in the graphics folder.
For reference, the folder in this mod can be found in the following directory: Super Cat Wars/data/gfx/packs/Classic/backgrounds. In Super Mario War, the folder can be found in Super Mario War/gfx/packs/Classic/backgrounds.

== Inserting custom backgrounds into Super Cat Wars/Super Mario War ==
- A background is a backdrop of the map itself which is sized at the same resolution as the game itself, "640x480 pixels".
- A background may contain a music category followed by the name of the map itself. Example is: Land_CatLandNO.
-- The following music categories can be used: Battle, Bonus, Castle, Clouds, Desert, Ghost, Land, Platforms, Snow, Underground, and Underwater.
- The file format backgrounds use is usually 24-bit PNG.

/!\ CAUTION: Backgrounds larger or smaller than 640x480 pixels can cause glitches, such as afterimages, glitched background scrolls, and even game crashes.
/!\ CAUTION: Backgrounds should ALWAYS be saved in 24-bit PNG, otherwise thumbnails of maps with backgrounds higher than 24-bit will not generate and appear blank. This error appears as "Blit combination not supported" when running the game with a debug console.
/!\ CAUTION: DO NOT DELETE LAND_CLASSIC. This is required for the game to run, and will crash the game if it does not exist in this folder.

--------------------------------------------
GAME OF ORIGINS
--------------------------------------------
Games which the backgrounds are taken from include:

NEUTRONIZED
Notes: Some SCT-styled backgrounds have been given all-new color alts, including day/afternoon/night alts for certain backgrounds which do not exist in their source games. This is to increase the diversity of level themes.

- Super Cat Tales
- Super Cat Tales 2
- Drop Wizard (Night version of Cedar Woods originates from the web browser demo.)
- Drop Wizard Tower
- Slime Pizza
- Slime Labs (Some backgrounds originate from the intro and ending cutscenes)
- Slime Laboratory 2
- Hoop and Pop (denoted by HNP in some BG names)
- Egg Blast
- Mimelet
- Swap-Swap Panda
- Picnic Penguin (The city background originates from the intro cutscene.)
- Dino Quake
- Mineblast!! (Some backgrounds originate from cutscenes.)
- Snow Kids (Some backgrounds originate from the intro cutscene and title screen.)
- Little Fin (Some backgrounds originate from the intro and ending cutscenes)

THOMAS K. YOUNG
Notice: Some backgrounds may be given alternate color alts using the SCT background palettes due to their nature of being similar to the SCT art style in some way.

- Dadish (There are two versions of the Abaro Woods background which were changed between updates at one point, these are in SCW for preservation.)
- Dadish 2
- Super Fowlst (Since the source backgrounds are extremely large, their sizes have been truncated and resized to fit a lot of details into a 640x480 space, and to keep pixel size consistency.)
- Super Fowlst 2

DRAWN AND EDITED BY HEXELECTRON
The following background filenames are custom-made assets by Hexelectron:

- Hikari City Arena (Story Mode)
- Ultima Stadium (S3RL Concert) (Story Mode)
- Dark Water Temple Statue (Story Mode)
- Underwater_OceanReef (Custom-made, an attempt at a SCT-styled background, but it just doesn't feel like one, but I decided to keep it anyway.)
- Land_Classic (A SCT-styled version of the SMB3 Classic Blocks BG, used to avoid SCW from crashing, since it's an integral file.)

DRAWN BY MRGREENMAN
Special thanks to MrGreenMan for sending these backgrounds:
- Battle_CustomDojo
- Land_CustomFantasyLand
