--------------------------------------------
GFX Pack - Powerups
--------------------------------------------
The following denote the purposes of the images used here:

Extra Life Powerups:
- 1uppowerup - 1up Mushroom/Green Sora Fruit
- 2uppowerup - 2up Mushroom/Pink Sora Fruit
- 3uppowerup - 3up Mushroom/Blue Sora Fruit
- 5uppowerup - 5up Mushroom/Golden Fruit
- poisonpowerup - Poison Mushroom/Poison Fruit. Kills you when touched.

- bobombpowerup - Bob-omb/Kobolt Jr. Transforms the player into an exploding Bob-omb/Kobolt Jr toy when touched.
- bombpowerup - Bomb. Allows the player to throw bombs.
- boomerangpowerup - Boomerang. Allows the player to throw returning boomerangs.
- bulletbillpowerup - Bullet Bill/Bird Swarm. Can be used to create a swarm of Bullet Bills/birds that flood the map and hit players.
- clockpowerup - Clock/Hourglass. Used to slow down opponents.
- extratimepowerup - Extra Clock/Hourglass, used in Time Limit to add 30 seconds to the timer
- featherpowerup - Cape Feather/Olli's Cloak. Allows players to perform multi-jumps and a cape spin. Has two frames for its animation.
- fireflower - Fire Flower/Chili Pepper. Shoots fireballs when equipped.
- hammerpowerup - Hammer. Shoots flying hammers when equipped.
- heartpowerup - Heart Container. Restores health or extends maximum HP in Health Mode.
- icewandpowerup - Ice Wand/Freeze Pop. Freezes players with ice spell projectiles. Frozen players can be killed by touching them.
- jailkeypowerup - Jail Key, frees players from jail if used in Jail Mode.
- large - Powerup icons (2x). Used for powerup settings, Bonus Wheel, etc.
- leafpowerup - Super Leaf/Tanuki's leaf. Grants a tail that allows gliding and tail spins. Has two frames for its animation.
- modpowerup - MOD Block/Thunder Bomb. Kills players in midair when used.
- mysterymushroom - Mystery Mushroom/Swap Scepter. Used to swap players' positions.
- podobopowerup - Lava Bubble/Fireball. Releases lots of lava bubbles if used.
- powpowerup - POW Block/Quake Bomb. Kills players on the ground when used.
- pwings - P-Wing/Balloon. Allows players to fly with a pair of wings or a balloon attached to their back.
- small - Powerup icons (1x). Used for item storage on the player HUD.
- starpowerup - Super Star/Golden Cat. Grants invincibility for a short period of time.
- tanooki - Tanooki Suit/Moon Crystal. A powerup that cannot be overrided until death that allows players to transform into an invincible statue/invisible version of themselves.

MAP ITEMS
- kuriboshoe - Collective sprite sheet containing graphics for the Kuribo's Shoe/Rollerskates & Spiky Shoe. Top row contains two frames per shoe while facing right, bottom row is for facing left.
- spike - Carryable Spike/Jello.
- spring - Trampoline/Bouncy Mushrooms. Last three frames are only used when the player is bouncing on top of them. Top row is for the regular green spring and the bottom row is for the stronger orange/red spring.
- throwbox - Crates. They contain four frames.