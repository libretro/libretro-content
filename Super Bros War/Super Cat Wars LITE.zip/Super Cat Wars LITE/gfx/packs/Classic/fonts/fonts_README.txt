--------------------------------------------
GFX Pack - Fonts
--------------------------------------------
The following denote the purposes of the images used here:

- font_large - In-game font that displays during a game match. You may see this when triggering certain states (like becoming a Shy Guy or Chicken).
- font_small - See above
- race - Numbers that appear on the race panels in Race Mode
- score - Numbers that appear on the players' score/lives.