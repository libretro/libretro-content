This folder is where screenshots taken in-game are written there.

Press the [INSERT] key to take a screenshot.

The files are named using a timestamp indicating when the screenshot was taken, while ending with the ".png" extension.